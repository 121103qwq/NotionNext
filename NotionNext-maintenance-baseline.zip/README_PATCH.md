# README 顶部补丁：下游分支说明

将下面内容添加到现有 `README.md` 的主标题之后。此文件只提供补丁文本，不替换或重写原 README。

---

> [!IMPORTANT]
> **下游分支说明**
>
> 本仓库 `121103qwq/NotionNext` 是 [`tangly1024/NotionNext`](https://github.com/tangly1024/NotionNext) 的非官方下游分支，由本分支维护者独立维护。
>
> 本分支的修改、发布、Issue 处理和兼容性结论仅代表本下游仓库，不代表上游项目或上游维护者。下游分支维护者不是上游项目维护者。
>
> 维护重点包括依赖与构建兼容性、主题回归检查、部署验证和文档完善。计划任务及其状态请参阅 [`ROADMAP.md`](./ROADMAP.md)，分支关系与维护边界请参阅 [`FORK_NOTES.md`](./FORK_NOTES.md)。未被实际执行的构建、测试或部署检查不会被描述为已经通过。

---
